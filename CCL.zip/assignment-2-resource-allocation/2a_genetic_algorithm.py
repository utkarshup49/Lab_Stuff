# =====================================================================
#  Assignment 2(a)  -  Genetic Algorithm for Cloud Resource Allocation
#  Cloud Computing Lab
#
#  Allocates tasks to virtual machines using a Genetic Algorithm and
#  compares it against FCFS and Random allocation.
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import random
import numpy as np
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# CPU capacity of each VM. The number of VMs is taken from this list,
# so adding a 6th number here gives you a 6th VM automatically.
VM_CAPACITY = [10, 15, 20, 25, 30]

USE_RANDOM_TASKS = True    # True  = generate tasks randomly (seeded)
                           # False = use MANUAL_TASKS below
NUM_TASKS = 20             # how many tasks when generating randomly
SEED = 10                  # same seed = same tasks every run

# Used ONLY when USE_RANDOM_TASKS = False.
# One line per task:  (cpu required, execution time)
MANUAL_TASKS = [
    (5, 4), (3, 7), (8, 2), (6, 9), (2, 5),
    (9, 3), (4, 8), (7, 6), (1, 4), (5, 7),
]

# Genetic Algorithm settings
POPULATION_SIZE = 50
GENERATIONS = 100
MUTATION_RATE = 0.1
SELECTION_KEEP = 10        # how many best chromosomes survive each generation

SHOW_GRAPH = True          # set to False to skip the convergence graph

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

NUM_VMS = len(VM_CAPACITY)


class CloudTask:
    def __init__(self, task_id, cpu_required, execution_time):
        self.task_id = task_id
        self.cpu_required = cpu_required
        self.execution_time = execution_time


def generate_tasks():
    if not USE_RANDOM_TASKS:
        return [CloudTask(i, cpu, ex)
                for i, (cpu, ex) in enumerate(MANUAL_TASKS)]
    random.seed(SEED)
    return [CloudTask(i, random.randint(1, 10), random.randint(2, 10))
            for i in range(NUM_TASKS)]


def simulate_cloud(tasks, allocation):
    """Run every task on the VM it was allocated to.

    Each VM handles one task at a time, so the tasks sent to a VM simply
    queue up behind each other in order. All tasks are submitted at
    time 0, so a task's waiting time is just when it finally starts.
    """
    free = [0] * NUM_VMS                 # when each VM becomes free
    results = []
    for task in tasks:                   # tasks are taken in ID order
        vm = allocation[task.task_id]    # which VM this task was given
        start = free[vm]                 # it waits for that VM to be free
        free[vm] = start + task.execution_time    # now busy until here
        results.append({"task": task.task_id, "vm": vm, "start": start,
                        "finish": free[vm], "waiting": start,
                        "execution": task.execution_time})
    return results


def calculate_metrics(results):
    makespan = max(r["finish"] for r in results)
    average_waiting = np.mean([r["waiting"] for r in results])
    total_execution = sum(r["execution"] for r in results)
    return makespan, average_waiting, total_execution


def display_allocation(algorithm, allocation):
    print("\n" + "-" * 44)
    print(algorithm, "RESOURCE ALLOCATION")
    print("-" * 44)
    for i in range(0, len(allocation), 5):
        print("   ".join(f"T{i + j:<2}->VM{v}"
                         for j, v in enumerate(allocation[i:i + 5])))


class GeneticAlgorithm:
    def __init__(self, tasks):
        self.tasks = tasks
        self.num_tasks = len(tasks)

    def create_chromosome(self):
        """One chromosome = one complete allocation (a VM for each task)."""
        return [random.randint(0, NUM_VMS - 1) for task in self.tasks]

    def fitness(self, chromosome):
        """Lower is better. Makespan, plus a penalty for a VM too small."""
        vm_time = [0] * NUM_VMS          # total work piled on each VM
        penalty = 0
        for task, vm in zip(self.tasks, chromosome):
            # A huge penalty makes any illegal allocation lose automatically.
            if task.cpu_required > VM_CAPACITY[vm]:
                penalty += 1000
            vm_time[vm] += task.execution_time
        # max() = the busiest VM = when everything is finished = makespan.
        return max(vm_time) + penalty

    def selection(self, population):
        # Sort so the lowest (best) makespan comes first, keep the top few.
        population.sort(key=self.fitness)
        return population[:SELECTION_KEEP]

    def crossover(self, p1, p2):
        # Cut both parents at the same random point and swap the tails,
        # so each child inherits a block of decisions from each parent.
        point = random.randint(1, self.num_tasks - 1)
        return p1[:point] + p2[point:], p2[:point] + p1[point:]

    def mutation(self, chromosome):
        # Each gene has a small chance of being moved to a random VM.
        # This is what stops the whole population becoming identical.
        for i in range(self.num_tasks):
            if random.random() < MUTATION_RATE:
                chromosome[i] = random.randint(0, NUM_VMS - 1)
        return chromosome

    def run(self):
        population = [self.create_chromosome()
                      for i in range(POPULATION_SIZE)]
        best_solution, best_fitness, history = None, float("inf"), []

        for generation in range(GENERATIONS):
            population = self.selection(population)   # survival of the fittest
            current_fitness = self.fitness(population[0])   # [0] is the best
            # Remember the best ever seen, in case a later generation is worse.
            if current_fitness < best_fitness:
                best_fitness = current_fitness
                best_solution = population[0].copy()
            history.append(best_fitness)

            # ELITISM: the survivors are copied into the next generation
            # unchanged, so the best answer can never be lost.
            new_population = list(population)
            # Fill the rest of the population with children of the survivors.
            while len(new_population) < POPULATION_SIZE:
                c1, c2 = self.crossover(random.choice(population),
                                        random.choice(population))
                new_population.append(self.mutation(c1))
                if len(new_population) < POPULATION_SIZE:
                    new_population.append(self.mutation(c2))
            population = new_population

        print("\n" + "=" * 30)
        print("GENETIC ALGORITHM RESULT")
        print("=" * 30)
        print("Best Fitness:", best_fitness)
        print("Best Allocation:", best_solution)
        return best_solution, history


def fcfs_allocation(tasks):
    """Baseline: always send the next task to the least loaded VM."""
    allocation, load = [], [0] * NUM_VMS
    for task in tasks:
        vm = load.index(min(load))       # whichever VM has the least work
        allocation.append(vm)
        load[vm] += task.execution_time
    return allocation


def random_allocation(tasks):
    """Baseline: send each task to a random VM."""
    return [random.randint(0, NUM_VMS - 1) for task in tasks]


# ----------------------------- run it --------------------------------
print("\nCLOUD RESOURCE ALLOCATION")
tasks = generate_tasks()
print("\nNumber of Tasks:", len(tasks))
print("Number of VMs:", NUM_VMS)

metrics = {}

fcfs = fcfs_allocation(tasks)
display_allocation("FCFS", fcfs)
metrics["FCFS"] = calculate_metrics(simulate_cloud(tasks, fcfs))

rnd = random_allocation(tasks)
display_allocation("RANDOM", rnd)
metrics["Random"] = calculate_metrics(simulate_cloud(tasks, rnd))

ga_allocation, history = GeneticAlgorithm(tasks).run()
display_allocation("GENETIC ALGORITHM", ga_allocation)
metrics["Genetic Algorithm"] = calculate_metrics(
    simulate_cloud(tasks, ga_allocation))

print("\n" + "=" * 46)
print("ALGORITHM PERFORMANCE COMPARISON")
print("=" * 46)
print(f"{'Algorithm':<20}{'Makespan':<15}{'Avg Waiting':<15}")
print("-" * 45)
for name, m in metrics.items():
    print(f"{name:<20}{m[0]:<15.2f}{m[1]:<15.2f}")

if SHOW_GRAPH:
    plt.figure(figsize=(8, 4))
    plt.plot(history, linewidth=2)
    plt.xlabel("Generation")
    plt.ylabel("Best Fitness")
    plt.title("GA Convergence for Cloud Resource Allocation")
    plt.grid(True)
    plt.show()
