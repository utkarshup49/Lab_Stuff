# =====================================================================
#  Assignment 2(b)  -  Bacterial Foraging Optimization (BFO)
#                      for Cloud Resource Allocation
#  Cloud Computing Lab
#
#  BFO imitates how bacteria search for food. Three nested loops:
#    chemotaxis            - tumble (a random move); if it improved,
#                            swim (keep moving the same way)
#    reproduction          - the best half is copied twice
#    elimination-dispersal - a few bacteria are randomly restarted
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import random
import numpy as np
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# CPU capacity of each VM. The number of VMs is taken from this list.
VM_CAPACITY = [10, 15, 20, 25, 30]

USE_RANDOM_TASKS = True    # True  = generate tasks randomly (seeded)
                           # False = use MANUAL_TASKS below
NUM_TASKS = 20             # how many tasks when generating randomly
SEED = 10                  # same seed = same tasks every run

# Used ONLY when USE_RANDOM_TASKS = False.
# One line per task:  (cpu required, execution time)
MANUAL_TASKS = [
    (5, 4), (3, 7), (8, 2), (6, 9), (2, 5),
    (9, 3), (4, 8), (7, 6), (1, 4), (5, 7),
]

# BFO settings
S = 30                     # number of bacteria
Nc = 20                    # chemotactic steps
Ns = 4                     # swimming length
Nre = 4                    # reproduction steps
Ned = 2                    # elimination-dispersal events
Ped = 0.20                 # probability a bacterium is eliminated

SHOW_GRAPH = True          # set to False to skip the convergence graph

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

NUM_VMS = len(VM_CAPACITY)


class CloudTask:
    def __init__(self, task_id, cpu_required, execution_time):
        self.task_id = task_id
        self.cpu_required = cpu_required
        self.execution_time = execution_time


def generate_tasks():
    if not USE_RANDOM_TASKS:
        return [CloudTask(i, cpu, ex)
                for i, (cpu, ex) in enumerate(MANUAL_TASKS)]
    random.seed(SEED)
    return [CloudTask(i, random.randint(1, 10), random.randint(2, 10))
            for i in range(NUM_TASKS)]


def simulate_cloud(tasks, allocation):
    """Each VM handles one task at a time, so tasks sent to the same VM
    queue up behind each other. All tasks are submitted at time 0."""
    free = [0] * NUM_VMS
    results = []
    for task in tasks:
        vm = allocation[task.task_id]
        start = free[vm]
        free[vm] = start + task.execution_time
        results.append({"task": task.task_id, "vm": vm, "start": start,
                        "finish": free[vm], "waiting": start,
                        "execution": task.execution_time})
    return results


def calculate_metrics(results):
    makespan = max(r["finish"] for r in results)
    average_waiting = np.mean([r["waiting"] for r in results])
    total_execution = sum(r["execution"] for r in results)
    return makespan, average_waiting, total_execution


def display_allocation(algorithm, allocation):
    print("\n" + "-" * 44)
    print(algorithm, "RESOURCE ALLOCATION")
    print("-" * 44)
    for i in range(0, len(allocation), 5):
        print("   ".join(f"T{i + j:<2}->VM{v}"
                         for j, v in enumerate(allocation[i:i + 5])))


class BFO:
    def __init__(self, tasks):
        self.tasks = tasks
        self.num_tasks = len(tasks)
        self.population = []

    def create_bacterium(self):
        """One bacterium = one complete allocation."""
        return [random.randint(0, NUM_VMS - 1)
                for i in range(self.num_tasks)]

    def fitness(self, solution):
        """Lower is better: makespan + load imbalance + capacity penalty."""
        vm_load = [0] * NUM_VMS          # total work piled on each VM
        penalty = 0
        for task, vm in zip(self.tasks, solution):
            # A huge penalty makes any illegal allocation lose automatically.
            if task.cpu_required > VM_CAPACITY[vm]:
                penalty += 1000
            vm_load[vm] += task.execution_time
        # max()  = makespan (when the busiest VM finishes)
        # std()  = how UNEVEN the VM loads are; charging for it pushes BFO
        #          towards balanced allocations, not just short ones.
        return max(vm_load) + 0.5 * np.std(vm_load) + penalty

    def tumble(self, bacterium):
        """A random move: one task is sent to a different VM."""
        new = bacterium.copy()           # never edit the original in place
        task_id = random.randint(0, self.num_tasks - 1)   # pick one task
        new_vm = random.randint(0, NUM_VMS - 1)           # and a new VM
        new[task_id] = new_vm
        return new

    def swim(self, bacterium, current_fitness):
        """Keep tumbling in the same spirit while it keeps improving."""
        best, best_fit = bacterium.copy(), current_fitness
        # Keep taking more steps the same way while they keep helping.
        # This is what makes BFO exploit a good direction instead of
        # wandering randomly. Ns caps how far it can swim in one go.
        for s in range(Ns):
            new = self.tumble(best)
            new_fit = self.fitness(new)
            if new_fit < best_fit:
                best, best_fit = new, new_fit
            else:
                break                        # it stopped helping - stop
        return best, best_fit

    def elimination_dispersal(self):
        # Each bacterium has a Ped chance of being thrown away and replaced
        # by a fresh random one. This is the escape hatch from local optima.
        for i in range(S):
            if random.random() < Ped:
                self.population[i] = self.create_bacterium()

    def run(self):
        self.population = [self.create_bacterium() for i in range(S)]
        best_solution, best_fitness, history = None, float("inf"), []

        for ed in range(Ned):                        # ELIMINATION-DISPERSAL
            for rep in range(Nre):                   # REPRODUCTION
                for chem in range(Nc):               # CHEMOTAXIS
                    fitness_values = []
                    for i in range(S):
                        cur = self.fitness(self.population[i])
                        if cur < best_fitness:
                            best_fitness = cur
                            best_solution = self.population[i].copy()

                        new = self.tumble(self.population[i])      # TUMBLE
                        if self.fitness(new) < cur:   # the move helped
                            self.population[i] = new
                            cur = self.fitness(new)

                        imp, imp_fit = self.swim(self.population[i], cur)
                        if imp_fit < cur:                          # SWIM
                            self.population[i], cur = imp, imp_fit
                        fitness_values.append(cur)

                    if min(fitness_values) < best_fitness:
                        best_fitness = min(fitness_values)
                        best_solution = self.population[
                            fitness_values.index(best_fitness)].copy()
                    history.append(best_fitness)

                # REPRODUCTION: sort by fitness, throw away the worse half,
                # and let the better half reproduce - each survivor is copied
                # twice, so the population size stays the same.
                ranked = sorted(self.population, key=self.fitness)
                self.population = [b.copy() for b in ranked[:S // 2]
                                   for t in (0, 1)][:S]
            self.elimination_dispersal()

        print("\n" + "=" * 35)
        print("BFO OPTIMIZATION COMPLETED")
        print("=" * 35)
        print("Best Fitness:", best_fitness)
        print("Best Allocation:", best_solution)
        return best_solution, history


# ----------------------------- run it --------------------------------
print("\nCLOUD RESOURCE ALLOCATION USING BFO")
tasks = generate_tasks()
print("\nNumber of Tasks:", len(tasks), " Number of VMs:", NUM_VMS)
print("VM Capacities:", VM_CAPACITY)

print("\nTASK INFORMATION (CPU, Execution time)")
print("-" * 44)
for i in range(0, len(tasks), 4):
    print("   ".join(f"T{t.task_id:<2}({t.cpu_required:2d},{t.execution_time:2d})"
                     for t in tasks[i:i + 4]))

allocation, history = BFO(tasks).run()
display_allocation("BFO", allocation)

makespan, average_waiting, total_execution = calculate_metrics(
    simulate_cloud(tasks, allocation))

print("\n" + "=" * 35)
print("SIMULATION RESULTS")
print("=" * 35)
print("Makespan:", makespan)
print("Average Waiting Time:", round(average_waiting, 2))
print("Total Execution Time:", total_execution)

if SHOW_GRAPH:
    plt.figure(figsize=(8, 4))
    plt.plot(history, linewidth=2)
    plt.xlabel("Iteration")
    plt.ylabel("Best Fitness")
    plt.title("BFO Convergence for Cloud Resource Allocation")
    plt.grid(True)
    plt.show()
