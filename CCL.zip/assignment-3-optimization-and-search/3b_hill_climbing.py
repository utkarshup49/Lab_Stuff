# =====================================================================
#  Assignment 3(b)  -  Hill Climbing
#  Cloud Computing Lab
#
#  Hill Climbing looks at the neighbour on each side, moves to whichever
#  is better, and stops the moment neither is better than where it
#  already stands. That "stop" is the whole algorithm - and also its
#  weakness: on a bumpy function it stops at the first local maximum.
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# The function to MAXIMISE. Change the formula to whatever is asked,
# for example:  return -(x - 2) ** 2 + 10     or     return -x ** 2
def f(x):
    return -(x - 5) ** 2 + 25


START_X = 0                # where the climb starts
STEP = 1                   # how far it moves each time
MAX_STEPS = 10000          # safety stop, so it can never loop forever

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

x = START_X      # current position
steps = 0        # only used to stop a runaway loop

while steps < MAX_STEPS:
    # Look at both neighbours and move to whichever is higher than here.
    if f(x - STEP) > f(x):          # the left neighbour is better
        x = x - STEP
    elif f(x + STEP) > f(x):        # the right neighbour is better
        x = x + STEP
    else:
        break                       # no better neighbour -> STOP
    steps += 1
    print(f"x = {x}, f(x) = {f(x)}")   # one line per uphill move

print("\nFinal Solution")
print("-" * 20)
print("Best x =", x)
print("Maximum value =", f(x))
