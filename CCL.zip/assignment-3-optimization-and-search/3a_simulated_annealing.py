# =====================================================================
#  Assignment 3(a)  -  Simulated Annealing
#  Cloud Computing Lab
#
#  Simulated Annealing is hill climbing that is allowed to ACCEPT A
#  WORSE solution, with probability e^(-delta / T). That is how it
#  escapes a local minimum. The temperature T falls every iteration,
#  so late in the run it stops accepting worse moves and settles.
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import random
import math
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# The function to MINIMISE. Change the formula to whatever is asked,
# for example:  return (x - 3) ** 2 + 5      or      return abs(x)
def cost(x):
    return x ** 2


START_X = 10               # where the search starts
TEMPERATURE = 100          # starting temperature (higher = more exploring)
COOLING_RATE = 0.95        # temperature is multiplied by this each step
ITERATIONS = 50            # try 100 or more for a closer answer
STEP = 1                   # neighbours are picked from x - STEP to x + STEP

SEED = 1                   # same seed = same run every time.
                           # Set SEED = None for a different run each time.

SHOW_GRAPH = True          # set to False to skip the cost graph

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

if SEED is not None:
    random.seed(SEED)

x = START_X                  # where the search currently is
current_cost = cost(x)       # the cost at that point
best_x, best_cost = x, current_cost   # the best point seen SO FAR
temperature = TEMPERATURE    # falls a little every iteration
history = []                 # cost at each step, for the graph

print("\nSimulated Annealing Started")
print("-" * 56)

for i in range(ITERATIONS):
    new_x = x + random.uniform(-STEP, STEP)   # a random nearby point
    delta = cost(new_x) - current_cost        # negative means it is BETTER

    # Accept if it is better, otherwise accept it anyway with
    # probability e^(-delta / temperature).  <-- the key line
    if delta < 0 or random.random() < math.exp(-delta / temperature):
        x = new_x                             # move there
        current_cost = cost(new_x)
        # The current point may be worse than one we passed earlier,
        # so the best-ever point is remembered separately.
        if current_cost < best_cost:
            best_x, best_cost = x, current_cost

    print(f"Iteration: {i + 1:3d} | x = {x:8.4f} | "
          f"Cost = {current_cost:8.4f} | Temperature = {temperature:8.4f}")

    history.append(current_cost)
    # Cooling: as T falls, exp(-delta/T) shrinks, so bad moves are accepted
    # less and less often and the search settles down.
    temperature *= COOLING_RATE

print("-" * 56)
print("Simulated Annealing Completed")
print(f"Best solution x = {best_x:.4f}")
print(f"Minimum value   = {best_cost:.4f}")

if SHOW_GRAPH:
    plt.figure(figsize=(8, 4))
    plt.plot(history, linewidth=2)
    plt.xlabel("Iteration")
    plt.ylabel("Cost")
    plt.title("Simulated Annealing - cost at each iteration")
    plt.grid(True)
    plt.show()
