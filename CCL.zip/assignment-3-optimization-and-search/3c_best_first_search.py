# =====================================================================
#  Assignment 3(c)  -  Best First Search
#  Cloud Computing Lab
#
#  Always expands the unvisited node with the SMALLEST heuristic h(n),
#  using a priority queue. It is greedy: it looks only at how close a
#  node seems to the goal and ignores the cost already spent, so it is
#  NOT guaranteed to find the shortest path. (A* fixes that by using
#  f(n) = g(n) + h(n).)
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import heapq
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# Which nodes each node leads to. Any graph works - just list them.
GRAPH = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': [],
    'E': [],
    'F': [],
    'G': [],
}

# The heuristic value of every node (how close it looks to the goal).
# Every node in GRAPH needs one. The goal is normally 0.
HEURISTIC = {'A': 6, 'B': 4, 'C': 3, 'D': 6, 'E': 2, 'F': 1, 'G': 0}

START = 'A'
GOAL = 'G'

SHOW_GRAPH = True          # set to False to skip the picture of the graph

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

# Friendly checks, so a typo gives a clear message instead of a crash.
assert START in GRAPH, f"START '{START}' is not a node in GRAPH."
assert GOAL in GRAPH, f"GOAL '{GOAL}' is not a node in GRAPH."
for node, neighbours in GRAPH.items():
    assert node in HEURISTIC, f"Node '{node}' has no value in HEURISTIC."
    for nb in neighbours:
        assert nb in GRAPH, (
            f"'{node}' points to '{nb}', but '{nb}' is not a key in GRAPH. "
            f"Add  '{nb}': []  if it has no neighbours.")


def best_first_search(graph, heuristic, start, goal):
    # A heap keeps the smallest h at the front, so popping always gives
    # the most promising unvisited node. Tuples sort by h first.
    pq = [(heuristic[start], start)]        # priority queue: (h value, node)
    visited = set()                         # nodes already expanded
    order = []                              # the order they were expanded in

    while pq:
        h_value, current = heapq.heappop(pq)    # smallest h comes out first
        # The same node can be pushed more than once by different parents;
        # skip it if it has already been expanded.
        if current in visited:
            continue

        print("Visiting:", current)
        visited.add(current)
        order.append(current)

        if current == goal:
            print("Goal reached:", goal)
            return order

        # Push every unvisited neighbour; the heap decides what comes next.
        for neighbour in graph[current]:
            if neighbour not in visited:
                heapq.heappush(pq, (heuristic[neighbour], neighbour))

    print("Goal not found")
    return order


path = best_first_search(GRAPH, HEURISTIC, START, GOAL)
print("\nNodes visited in order:", " -> ".join(path))
print("Nodes never visited   :",
      ", ".join(sorted(set(GRAPH) - set(path))) or "(none)")


# ------------------- optional picture of the graph -------------------
if SHOW_GRAPH:
    # Work out a level (depth) for every node by walking out from START,
    # then spread the nodes of each level evenly across the width.
    level = {START: 0}
    queue = [START]
    while queue:
        node = queue.pop(0)
        for nb in GRAPH[node]:
            if nb not in level:
                level[nb] = level[node] + 1
                queue.append(nb)
    for node in GRAPH:                      # nodes not reachable from START
        level.setdefault(node, max(level.values()) + 1)

    rows = {}
    for node, lv in level.items():
        rows.setdefault(lv, []).append(node)

    pos = {}
    for lv, nodes in rows.items():
        for i, node in enumerate(sorted(nodes)):
            pos[node] = ((i + 1) / (len(nodes) + 1), -lv)

    on_path = set(path)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for node, neighbours in GRAPH.items():
        for nb in neighbours:
            hot = node in on_path and nb in on_path
            ax.plot([pos[node][0], pos[nb][0]], [pos[node][1], pos[nb][1]],
                    color="#B4411F" if hot else "#BBBBBB",
                    linewidth=2.5 if hot else 1.3, zorder=1)
    for node, (px, py) in pos.items():
        hot = node in on_path
        ax.scatter([px], [py], s=900,
                   facecolor="#FFE2D6" if hot else "white",
                   edgecolor="#B4411F" if hot else "#666666",
                   linewidth=2.2 if hot else 1.3, zorder=2)
        ax.text(px, py, node, ha="center", va="center",
                fontsize=12, fontweight="bold", zorder=3)
        ax.text(px, py - 0.22, f"h={HEURISTIC[node]}", ha="center",
                va="center", fontsize=9, zorder=3)
    ax.set_title(f"Best First Search:  {' -> '.join(path)}")
    ax.axis("off")
    ax.margins(0.15)
    plt.show()
