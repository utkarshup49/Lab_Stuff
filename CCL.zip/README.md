# Cloud Computing Lab

All lab programs for the Cloud Computing practical, one file per experiment.

**Every file is standalone.** Each one repeats its own `import` lines, so you can
open any single file in Jupyter or Colab, run it on its own, and it works. Nothing
imports anything from another file.

**Every file has one block to edit.** Near the top of each file:

```
# =====================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================
```

Change the numbers or the list inside that block and everything below adapts by
itself — the tables, the totals and the charts. You never need to touch the logic.

---

## Index

| # | Experiment | File |
|---|---|---|
| **1** | Task Scheduling | |
| 1(a) | FCFS | [`1a_fcfs.py`](assignment-1-task-scheduling/1a_fcfs.py) |
| 1(b) | Round Robin | [`1b_round_robin.py`](assignment-1-task-scheduling/1b_round_robin.py) |
| 1(c) | SJF | [`1c_sjf.py`](assignment-1-task-scheduling/1c_sjf.py) |
| 1(d) | Max-Min | [`1d_max_min.py`](assignment-1-task-scheduling/1d_max_min.py) |
| 1(e) | Min-Min | [`1e_min_min.py`](assignment-1-task-scheduling/1e_min_min.py) |
| **2** | Resource Allocation | |
| 2(a) | Genetic Algorithm | [`2a_genetic_algorithm.py`](assignment-2-resource-allocation/2a_genetic_algorithm.py) |
| 2(b) | BFO | [`2b_bfo.py`](assignment-2-resource-allocation/2b_bfo.py) |
| **3** | Optimization and Search | |
| 3(a) | Simulated Annealing | [`3a_simulated_annealing.py`](assignment-3-optimization-and-search/3a_simulated_annealing.py) |
| 3(b) | Hill Climbing | [`3b_hill_climbing.py`](assignment-3-optimization-and-search/3b_hill_climbing.py) |
| 3(c) | Best First Search | [`3c_best_first_search.py`](assignment-3-optimization-and-search/3c_best_first_search.py) |
| **4** | Jobs on VMs (J1–J6) | [`4_jobs_on_vms.py`](assignment-4-jobs-on-vms/4_jobs_on_vms.py) |

All six jobs of Assignment 4 run in **one** program, because they are scheduled
onto the VMs together — that is what the output table shows.

---

## Explanation / viva PDF

**[`pdfs/Cloud_Lab_Code_Explained.pdf`](pdfs/Cloud_Lab_Code_Explained.pdf)** — read
this in the five minutes before a viva. For every program it gives:

- **In one sentence** — the answer to "what does this do?"
- **The code** — what you change, and the algorithm, with a comment on almost
  every logic line (listings are read straight from these `.py` files, so they
  are never out of date)
- **How it works** — the same thing as numbered steps, to talk through
- **Complexity** — time and space, always with the reason, not just the formula
- **If the teacher asks** — the likely questions, with short answers

It ends with a complexity table for all eleven, an algorithm comparison table,
and six answers that are commonly gotten wrong.

---

## How to run

**Colab or Jupyter** — paste one file into a cell and run it. First time only:

```python
!pip install pandas numpy matplotlib
```

**Terminal**

```bash
pip install -r requirements.txt
python assignment-1-task-scheduling/1a_fcfs.py
```

No SimPy needed. The lab handout wrapped some programs in SimPy, but it only
paced the loop — it never changed a single printed value, so these run as plain
Python and give identical results.

---

## Changing the input

| File | What to change |
|---|---|
| `1a_fcfs.py` | `TASKS` — lines of `("name", arrival, burst)`. Arrivals may be in any order; the program sorts them. |
| `1b_round_robin.py` | `TASKS` — `("name", burst)` — and `QUANTUM` |
| `1c_sjf.py` | `TASKS` — `("name", burst)` |
| `1d_max_min.py`, `1e_min_min.py` | `TASKS`, `VMS`, and the `ET` table (one row per task, one column per VM) |
| `2a_genetic_algorithm.py`, `2b_bfo.py` | `VM_CAPACITY` sets how many VMs. Set `USE_RANDOM_TASKS = False` to use your own `MANUAL_TASKS` list. |
| `3a_simulated_annealing.py` | The `cost(x)` formula (minimised), `START_X`, `ITERATIONS` |
| `3b_hill_climbing.py` | The `f(x)` formula (maximised), `START_X`, `STEP` |
| `3c_best_first_search.py` | `GRAPH`, `HEURISTIC`, `START`, `GOAL` — any graph works |
| `4_jobs_on_vms.py` | `DATA`, `VMS`, and the `JOBS` list |

Add a 6th number to `VM_CAPACITY` and you get a 6th VM. Add a line to `TASKS` and
you get another task. Nothing else has to change.

### Extra jobs for Assignment 4

The bottom of `4_jobs_on_vms.py` has a **JOB LIBRARY** of about 30 ready-made
jobs — sort descending, median, standard deviation, second largest, count even,
cumulative sum, frequency count, linear search, and more. Copy any line into the
`JOBS` list to swap a job in. The imports at the top already cover all of them.

---

## Notes

- Charts can be turned off with `SHOW_GANTT = False` or `SHOW_GRAPH = False`.
- `2a` and `2b` use `SEED` so the random tasks are the same every run. Change the
  seed, or set `USE_RANDOM_TASKS = False`, to use your own task list.
- `3a` uses `SEED = 1` so the run repeats exactly. Set `SEED = None` for a
  different run each time.
- `3a` ends near x = 1.8 at 50 iterations, not at the true minimum 0 — the
  temperature is still high. Raise `ITERATIONS` to 100 to see it converge.
- The `pdfs/` folder has the written-up versions used for the practical file,
  plus an outputs sheet sized to cut out and paste. Heads up: those PDFs still
  use the lab handout's original numbering, where Simulated Annealing, Hill
  Climbing and Best First Search are labelled `2(c)` and `2(d)` rather than
  Assignment 3. The Python files in this repo use the index numbering above.
