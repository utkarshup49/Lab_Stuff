# =====================================================================
#  Assignment 4  -  Six Jobs running on Virtual Machines
#  Cloud Computing Lab
#
#  Six jobs (Sort, Search Smallest, Sum, Mean, Maximum, Reverse Order)
#  are each assigned a VM and executed. The program prints when each
#  job ran, what it returned, and how busy each VM was.
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import math
import statistics
import itertools
import collections


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# The data every job works on. Change these numbers to anything.
DATA = [23, 45, 15, 0, 17]

# The virtual machines. Add or remove names to change how many there are.
VMS = ["VM1", "VM2", "VM3"]

# The jobs to run.  Each line is:   ("name", what it does, burst time)
# To use a different job, copy any line from the JOB LIBRARY at the
# bottom of this file and paste it in here.
JOBS = [
    ("Sort",            lambda d: sorted(d),                4),
    ("Search Smallest", lambda d: min(d),                   2),
    ("Sum",             lambda d: sum(d),                   3),
    ("Mean",            lambda d: sum(d) / len(d),          3),
    ("Maximum",         lambda d: max(d),                   2),
    ("Reverse Order",   lambda d: d[::-1],                  4),
]

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

assert DATA, "DATA is empty - put at least one number in it."
assert VMS, "VMS is empty - there must be at least one VM."
assert JOBS, "JOBS is empty - there must be at least one job."

free = [0] * len(VMS)                    # when each VM becomes free
# 18 keeps the normal table lined up; it widens if you add a longer name.
width = max(18, max(len(name) for name, fn, bt in JOBS) + 2)

print("Input Data :", DATA)
print("=" * 78)
print(f"{'Job':<8}{'Task':<{width}}{'VM':<7}{'Start':<8}{'Finish':<8}Result")
print("=" * 78)

for i, (name, job, burst) in enumerate(JOBS):
    # Round robin: job 0 -> VM1, job 1 -> VM2, job 2 -> VM3, job 3 -> VM1...
    # The modulo makes it wrap around however many VMs there are.
    vm = i % len(VMS)
    start = free[vm]                     # it waits for that VM to be free
    free[vm] += burst                    # that VM is now busy until here
    # job(DATA) is where the actual work happens - the lambda from JOBS.
    print(f"{'Job-' + str(i + 1):<8}{name:<{width}}{VMS[vm]:<7}"
          f"{start:<8}{free[vm]:<8}{job(DATA)}")

# Makespan = when the LAST VM finishes = when all six jobs are done.
makespan = max(free)
print("\nMakespan :", makespan)
for i, vm in enumerate(VMS):
    # Utilization = how much of the total time this VM was actually working.
    print(f"{vm} busy time = {free[i]}   "
          f"utilization = {free[i] / makespan * 100:.2f} %")


# =====================================================================
#  JOB LIBRARY  -  copy any line you need into JOBS above.
#  (The imports at the top of this file already cover all of these.)
# =====================================================================
#
#   ("Sort Ascending",    lambda d: sorted(d),                        4),
#   ("Sort Descending",   lambda d: sorted(d, reverse=True),          4),
#   ("Search Smallest",   lambda d: min(d),                           2),
#   ("Search Largest",    lambda d: max(d),                           2),
#   ("Second Largest",    lambda d: sorted(set(d))[-2],               3),
#   ("Second Smallest",   lambda d: sorted(set(d))[1],                3),
#   ("Sum",               lambda d: sum(d),                           3),
#   ("Product",           lambda d: math.prod(d),                     3),
#   ("Mean",              lambda d: sum(d) / len(d),                  3),
#   ("Median",            lambda d: statistics.median(d),             3),
#   ("Mode",              lambda d: statistics.mode(d),               3),
#   ("Standard Deviation",lambda d: round(statistics.pstdev(d), 2),   4),
#   ("Variance",          lambda d: round(statistics.pvariance(d), 2),4),
#   ("Range (Max-Min)",   lambda d: max(d) - min(d),                  2),
#   ("Count of Elements", lambda d: len(d),                           1),
#   ("Reverse Order",     lambda d: d[::-1],                          4),
#   ("Remove Duplicates", lambda d: sorted(set(d)),                   3),
#   ("Count Even",        lambda d: len([x for x in d if x % 2 == 0]),2),
#   ("Count Odd",         lambda d: len([x for x in d if x % 2]),     2),
#   ("Even Numbers",      lambda d: [x for x in d if x % 2 == 0],     3),
#   ("Odd Numbers",       lambda d: [x for x in d if x % 2],          3),
#   ("Sum of Even",       lambda d: sum(x for x in d if x % 2 == 0),  3),
#   ("Sum of Odd",        lambda d: sum(x for x in d if x % 2),       3),
#   ("Squares",           lambda d: [x * x for x in d],               3),
#   ("Cumulative Sum",    lambda d: list(itertools.accumulate(d)),    3),
#   ("Frequency Count",   lambda d: dict(collections.Counter(d)),     3),
#   ("Linear Search 15",  lambda d: d.index(15) if 15 in d else -1,   2),
#   ("Is 45 Present",     lambda d: 45 in d,                          2),
#   ("Average of Top 3",  lambda d: sum(sorted(d)[-3:]) / 3,          3),
#   ("Positive Numbers",  lambda d: [x for x in d if x > 0],          3),
#
#  Note on "Linear Search 15" and "Is 45 Present": change the number
#  in BOTH places on that line to search for something else.
# =====================================================================
