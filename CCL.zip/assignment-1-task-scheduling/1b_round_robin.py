# =====================================================================
#  Assignment 1(b)  -  Round Robin Scheduling
#  Cloud Computing Lab
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import pandas as pd
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# One line per task:  ("name", burst time)
# All tasks are assumed to arrive at time 0 (the usual Round Robin question).
TASKS = [
    ("T1", 10),
    ("T2", 4),
    ("T3", 6),
    ("T4", 8),
    ("T5", 2),
]

QUANTUM = 2                # the time slice each task gets per turn

SHOW_GANTT = True          # set to False to skip the Gantt chart

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

COLORS = ["skyblue", "lightgreen", "orange", "pink", "yellow",
          "violet", "lightcoral", "khaki"]


def gantt(bars, title, rows=["CPU"]):
    """bars = list of (name, start, end, row_index)"""
    names = [b[0] for b in bars]
    order = sorted(set(names), key=names.index)
    fig, ax = plt.subplots(figsize=(10, 1.2 + 1.3 * len(rows)))
    for n, s, e, r in bars:
        ax.broken_barh([(s, e - s)], (r * 10 + 5, 8),
                       facecolors=COLORS[order.index(n) % len(COLORS)],
                       edgecolor="black")
        ax.text((s + e) / 2, r * 10 + 9, n, ha="center", va="center")
    ax.set_yticks([r * 10 + 9 for r in range(len(rows))])
    ax.set_yticklabels(rows)
    ax.set_xlabel("Time")
    ax.set_title(title)
    ax.grid(True)
    plt.show()


def report(df, title):
    makespan = df["CT"].max()
    print("=" * 60)
    print(title)
    print("=" * 60)
    print(df.to_string(index=False))
    print("\nAverage Waiting Time    :", round(df["WT"].mean(), 2))
    print("Average Turnaround Time :", round(df["TAT"].mean(), 2))
    print("Makespan                :", makespan)
    print("CPU Utilization         :",
          round(df["BT"].sum() / makespan * 100, 2), "%")
    print("Throughput              :",
          round(len(df) / makespan, 3), "Tasks/Unit Time")


# ------------------------- ROUND ROBIN -------------------------------
names = [n for n, b in TASKS]
burst = [b for n, b in TASKS]

remaining = burst.copy()                # time still left for each task
                                        # .copy() so burst[] stays untouched
completion = [0] * len(burst)
clock = 0
bars = []
order = []

# any() is True while at least one task still has time left to run.
while any(remaining):                   # one pass = one full cycle of turns
    for i in range(len(remaining)):
        if remaining[i]:
            # Give it a full quantum, unless less than that is left.
            run = min(QUANTUM, remaining[i])
            bars.append((names[i], clock, clock + run, 0))
            order.append(names[i])
            clock += run
            remaining[i] -= run                 # preempt: it goes to the back
            if remaining[i] == 0:               # finished on this turn
                completion[i] = clock

df = pd.DataFrame({"Task": names, "BT": burst, "CT": completion})
df["TAT"] = df.CT                       # AT = 0, so TAT = CT - 0 = CT
df["WT"] = df.CT - df.BT                # time in system minus time running
df = df[["Task", "BT", "WT", "TAT", "CT"]]

print("Execution order:", " ".join(order), "\n")
report(df, f"ROUND ROBIN SCHEDULING (Quantum = {QUANTUM})")

if SHOW_GANTT:
    gantt(bars, "Gantt Chart - Round Robin Scheduling")
