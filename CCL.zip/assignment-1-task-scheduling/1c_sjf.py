# =====================================================================
#  Assignment 1(c)  -  SJF  (Shortest Job First) Scheduling
#  Cloud Computing Lab
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import pandas as pd
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# One line per task:  ("name", burst time)
# All tasks are assumed to arrive at time 0 (the usual SJF question).
TASKS = [
    ("T1", 10),
    ("T2", 4),
    ("T3", 6),
    ("T4", 8),
    ("T5", 2),
]

SHOW_GANTT = True          # set to False to skip the Gantt chart

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

COLORS = ["skyblue", "lightgreen", "orange", "pink", "yellow",
          "violet", "lightcoral", "khaki"]


def gantt(bars, title, rows=["CPU"]):
    """bars = list of (name, start, end, row_index)"""
    names = [b[0] for b in bars]
    order = sorted(set(names), key=names.index)
    fig, ax = plt.subplots(figsize=(10, 1.2 + 1.3 * len(rows)))
    for n, s, e, r in bars:
        ax.broken_barh([(s, e - s)], (r * 10 + 5, 8),
                       facecolors=COLORS[order.index(n) % len(COLORS)],
                       edgecolor="black")
        ax.text((s + e) / 2, r * 10 + 9, n, ha="center", va="center")
    ax.set_yticks([r * 10 + 9 for r in range(len(rows))])
    ax.set_yticklabels(rows)
    ax.set_xlabel("Time")
    ax.set_title(title)
    ax.grid(True)
    plt.show()


def report(df, title):
    makespan = df["CT"].max()
    print("=" * 60)
    print(title)
    print("=" * 60)
    print(df.to_string(index=False))
    print("\nAverage Waiting Time    :", round(df["WT"].mean(), 2))
    print("Average Turnaround Time :", round(df["TAT"].mean(), 2))
    print("Makespan                :", makespan)
    print("CPU Utilization         :",
          round(df["BT"].sum() / makespan * 100, 2), "%")
    print("Throughput              :",
          round(len(df) / makespan, 3), "Tasks/Unit Time")


# ----------------------------- SJF -----------------------------------
# SJF runs the shortest job first - that single sort IS the algorithm.
tasks = sorted(TASKS, key=lambda t: t[1])   # t[1] is burst time

clock = 0        # when the CPU becomes free
rows = []        # one row of the result table per task
bars = []        # (name, start, end, row) for the Gantt chart

for name, burst in tasks:
    bars.append((name, clock, clock + burst, 0))
    # WT = clock, because everything scheduled before it has to finish first.
    # AT = 0, so TAT = CT = clock + burst.
    rows.append([name, burst, clock, clock + burst, clock + burst])
    clock += burst

df = pd.DataFrame(rows, columns=["Task", "BT", "WT", "TAT", "CT"])

report(df, "SHORTEST JOB FIRST (SJF) SCHEDULING")

if SHOW_GANTT:
    gantt(bars, "Gantt Chart - SJF Scheduling")
