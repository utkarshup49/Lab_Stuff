# =====================================================================
#  Assignment 1(e)  -  Min-Min Task Scheduling (multiple VMs)
#  Cloud Computing Lab
#
#  Run this file on its own. It needs nothing from any other file.
#
#  Min-Min: for every unassigned task work out its MINIMUM completion
#  time over all VMs, then dispatch the task whose minimum is the
#  SMALLEST (the shortest tasks are placed first).
# =====================================================================

import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

TASKS = ["T1", "T2", "T3", "T4", "T5"]
VMS = ["VM1", "VM2", "VM3"]

# Execution time of each TASK on each VM.
# One ROW per task, one COLUMN per VM - so the table must be
# len(TASKS) rows x len(VMS) columns.
#        VM1  VM2  VM3
ET = [
    [14, 10, 12],      # T1
    [16, 20, 18],      # T2
    [9, 12, 10],       # T3
    [7, 8, 6],         # T4
    [5, 4, 7],         # T5
]

SHOW_GANTT = True          # set to False to skip the Gantt chart

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

# A friendly check, so a wrong-sized table gives a clear message
# instead of a confusing crash.
assert len(ET) == len(TASKS), (
    f"ET has {len(ET)} rows but there are {len(TASKS)} tasks - "
    "one row per task is needed.")
for i, row in enumerate(ET):
    assert len(row) == len(VMS), (
        f"ET row {i + 1} ({TASKS[i]}) has {len(row)} values but there are "
        f"{len(VMS)} VMs - one value per VM is needed.")

COLORS = ["skyblue", "lightgreen", "orange", "pink", "yellow",
          "violet", "lightcoral", "khaki"]


def gantt(bars, title, rows):
    """bars = list of (name, start, end, row_index)"""
    names = [b[0] for b in bars]
    order = sorted(set(names), key=names.index)
    fig, ax = plt.subplots(figsize=(10, 1.2 + 1.3 * len(rows)))
    for n, s, e, r in bars:
        ax.broken_barh([(s, e - s)], (r * 10 + 5, 8),
                       facecolors=COLORS[order.index(n) % len(COLORS)],
                       edgecolor="black")
        ax.text((s + e) / 2, r * 10 + 9, n, ha="center", va="center")
    ax.set_yticks([r * 10 + 9 for r in range(len(rows))])
    ax.set_yticklabels(rows)
    ax.set_xlabel("Time")
    ax.set_title(title)
    ax.grid(True)
    plt.show()


# --------------------------- MIN-MIN ---------------------------------
ready = [0] * len(VMS)                 # when each VM becomes free
left = list(range(len(TASKS)))         # indexes of tasks not yet assigned
plan = []                              # (task, start, finish, vm) per task

print("=" * 60)
print("MIN-MIN TASK SCHEDULING")
print("=" * 60)
print("Task    VM      Start   Finish")

# One task is dispatched per pass, so this runs len(TASKS) times.
while left:
    candidates = []                    # (task, its best VM, that finish time)
    for t in left:
        # Finish time = when that VM frees up + how long this task takes on it.
        times = [ready[v] + ET[t][v] for v in range(len(VMS))]
        best_vm = times.index(min(times))      # the VM that finishes it soonest
        candidates.append((t, best_vm, min(times)))   # keep only that minimum

    # MIN-MIN -> pick the SMALLEST of those minimum completion times
    # c[2] is the minimum finish time. Taking min() of those minimums is
    # the ONLY line that makes this MIN-MIN rather than the other one.
    t, v, finish = min(candidates, key=lambda c: c[2])

    print(f"{TASKS[t]:<8}{VMS[v]:<8}{ready[v]:<8}{finish}")
    plan.append((TASKS[t], ready[v], finish, v))
    ready[v] = finish                  # that VM is now busy until here
    left.remove(t)                     # and this task is done being assigned

# Makespan = when the LAST VM finishes = when the whole batch is done.
print("\nMakespan :", max(ready))
for i, vm in enumerate(VMS):
    print(vm, "Completion Time :", ready[i])

if SHOW_GANTT:
    gantt(plan, "Gantt Chart - MIN-MIN TASK SCHEDULING", VMS)
