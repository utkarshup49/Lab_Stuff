# =====================================================================
#  Assignment 1(a)  -  FCFS  (First Come First Serve) Scheduling
#  Cloud Computing Lab
#
#  Run this file on its own. It needs nothing from any other file.
# =====================================================================

import pandas as pd
import matplotlib.pyplot as plt


# =====================================================================
#  >>>>>>>>>>  CHANGE ONLY THIS BLOCK  <<<<<<<<<<
# =====================================================================

# One line per task:  ("name", arrival time, burst time)
# Add or remove lines freely - the whole program adapts by itself.
TASKS = [
    ("T1", 0, 10),
    ("T2", 1, 4),
    ("T3", 2, 6),
    ("T4", 3, 8),
    ("T5", 4, 2),
]

SHOW_GANTT = True          # set to False to skip the Gantt chart

# =====================================================================
#  Nothing below here needs to be changed.
# =====================================================================

COLORS = ["skyblue", "lightgreen", "orange", "pink", "yellow",
          "violet", "lightcoral", "khaki"]


def gantt(bars, title, rows=["CPU"]):
    """bars = list of (name, start, end, row_index)"""
    names = [b[0] for b in bars]
    order = sorted(set(names), key=names.index)
    fig, ax = plt.subplots(figsize=(10, 1.2 + 1.3 * len(rows)))
    for n, s, e, r in bars:
        ax.broken_barh([(s, e - s)], (r * 10 + 5, 8),
                       facecolors=COLORS[order.index(n) % len(COLORS)],
                       edgecolor="black")
        ax.text((s + e) / 2, r * 10 + 9, n, ha="center", va="center")
    ax.set_yticks([r * 10 + 9 for r in range(len(rows))])
    ax.set_yticklabels(rows)
    ax.set_xlabel("Time")
    ax.set_title(title)
    ax.grid(True)
    plt.show()


def report(df, title):
    makespan = df["CT"].max()
    print("=" * 60)
    print(title)
    print("=" * 60)
    print(df.to_string(index=False))
    print("\nAverage Waiting Time    :", round(df["WT"].mean(), 2))
    print("Average Turnaround Time :", round(df["TAT"].mean(), 2))
    print("Makespan                :", makespan)
    print("CPU Utilization         :",
          round(df["BT"].sum() / makespan * 100, 2), "%")
    print("Throughput              :",
          round(len(df) / makespan, 3), "Tasks/Unit Time")


# ---------------------------- FCFS -----------------------------------
# FCFS runs tasks in the order they arrive, so sort by arrival time.
tasks = sorted(TASKS, key=lambda t: t[1])   # t[1] is arrival time

clock = 0        # the CPU's clock - the time the CPU is free again
rows = []        # one row of the result table per task
bars = []        # (name, start, end, row) for the Gantt chart

for name, arrival, burst in tasks:
    clock = max(clock, arrival)        # CPU idle until the task arrives
    waiting = clock - arrival          # how long it sat in the queue
    bars.append((name, clock, clock + burst, 0))
    clock += burst                     # non-preemptive: runs to completion
    # RT = WT here because the task starts once and is never interrupted.
    # CT = clock (just updated), TAT = CT - AT = how long it was in the system.
    rows.append([name, arrival, burst, waiting, waiting,
                 clock, clock - arrival])

df = pd.DataFrame(rows, columns=["Task", "AT", "BT", "WT", "RT", "CT", "TAT"])

report(df, "FIRST COME FIRST SERVE (FCFS) SCHEDULING")

if SHOW_GANTT:
    gantt(bars, "Gantt Chart - FCFS Scheduling")
